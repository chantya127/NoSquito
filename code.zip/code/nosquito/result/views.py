from django.shortcuts import render,redirect
from django.http import HttpResponse

def addPdf(request):
    return render(request,'result/result.html')
