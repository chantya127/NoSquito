from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.start, name='start'),
    path('city/<str:city_name>/', views.citywise, name="citywise"),
    path('mosquito/<str:mosquito_name>/', views.mosquitowise, name="mosquitowise"),
]