from django.shortcuts import render
import json

# Create your views here.
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

db = firestore.client()
ans=[]

disease = 'malaria'
areaname = 'kothrud'

keys = ['malaria','dengue','chikungunya','kalaazar','japaneseencephalitis','lymphaticfilariasis','yellowfever']

def start(request):
    disease = 'malaria'
    areaname = 'kothrud'

    if request.method == 'POST':
        disease = request.POST['dis']
        areaname = 'kothrud'
        

    cities=['Pune', 'Mumbai']
    mosquitos=['Abc', 'Xyz']

    diseases_dict = {
        'malaria': 0,'dengue': 0,'chikungunya': 0,'kalaazar': 0,'japaneseencephalitis': 0,'lymphaticfilariasis': 0,'yellowfever': 0
    }
    city="pune"
    #overall diseases percentage pie chart 
    docs = db.collection('co2_baited').where("city","==",city).get()

    #code
    for doc in docs:
        my_dict = doc.to_dict()
        for key in keys:
            if key in my_dict:
                diseases_dict[key]= diseases_dict[key] + my_dict[key]['percentage']

    ans.clear()
    values= []
    diseases = []
    for key in keys:
        ans.append(diseases_dict[key])
    

    for i in range(len(ans)):
        if ans[i]!=0:
            values.append(ans[i])
            diseases.append(keys[i])

    info = zip(diseases,values)

    #Bar Chart------------------------

    percentage_by_month = {'feb':0,'mar':0,'apr':0}
    docs = db.collection('co2_baited').where("city","==",city).get()
    for doc in docs:
        my_dict = doc.to_dict()
        if disease in my_dict:
            # print(my_dict[disease]['percentage'])
            date = my_dict['date'].split("_")[1]
            if date == "02":
                percentage_by_month['feb'] = percentage_by_month['feb'] + my_dict[disease]['percentage']
            elif date == "03":
                percentage_by_month['mar'] = percentage_by_month['mar'] + my_dict[disease]['percentage']
            elif date == "04":
                percentage_by_month['apr'] = percentage_by_month['apr'] + my_dict[disease]['percentage']
    
    
    months = ['feb','mar','apr']
    ans.clear()


    for month in months:
        ans.append(percentage_by_month[month])
    
    #print("Bar Chart-----------")
    #print(months,ans)
    
    #Bar Chart Ends------------------------

    #Line Chart------------------------
    docs = db.collection('co2_baited').get()
    dates= []
    for doc in docs:
        my_dict = doc.to_dict()
        dates.append(my_dict['date'])


    percentage_by_month = {'feb':0,'mar':0,'apr':0}
    for date in dates:
        date = date.split("_")[1]
        if date == "02":
            percentage_by_month['feb'] = percentage_by_month['feb'] + 1
        elif date == "03":
            percentage_by_month['mar'] = percentage_by_month['mar'] + 1
        elif date == "04":
            percentage_by_month['apr'] = percentage_by_month['apr'] + 1

    
    monthsL = ['feb','mar','apr']
    ansL=[]

    for month in monthsL:
        ansL.append(percentage_by_month[month])
    
    # print("Line Chart-----------")
    # print(monthsL,ansL)

    #Line Chart ends----------------------

    #Map1-----------------------
    
    map1 = []
    curr = []
    docs = db.collection('co2_baited').get()
    for doc in docs:
        curr.clear()
        my_dict = doc.to_dict()
        if (my_dict['location'] and my_dict['no']):
            loc = my_dict['location']
            loc = loc.split(",")
            curr.append(float(loc[0]))
            curr.append(float(loc[1]))
            curr.append(my_dict['no'])
            #print(curr)
            map1.append(list(curr))

    
    #Map2-------------------------
    final2 =[]
    curr1 = []
    docs = db.collection('co2_baited').get()
    for doc in docs:
        string = ''
        curr1.clear()
        my_dict = doc.to_dict()
        if (my_dict['location']):
            loc = my_dict['location']
            loc = loc.split(",")
            curr1.append(float(loc[0]))
            curr1.append(float(loc[1]))
            # curr2.append(list(curr1))
        if(my_dict['date'] and my_dict['ht']):
            string = ' date : '+ my_dict['date'] + ' br ' +'ht : ' + str(my_dict['ht'])
        for key in keys:
            if key in my_dict:
                string = string + ' br ' + key + ' : ' + str(my_dict[key]['percentage']) + ' '
        curr1.append(string)
        final2.append(list(curr1))

    map2=final2    
    #print(final2)

    #Areawise------
    #Area Pie Chart-------------
    area = []
    docs = db.collection('co2_baited').where("city","==",city).get()
    for doc in docs:
            my_dict = doc.to_dict()
            curr_area = my_dict['area']
            if curr_area not in area:
                area.append(curr_area)
    print(area)

    return render(request, 'dashboard/index.html', {'cities' : cities, 'mosquitos' : mosquitos, 'values' : values, 'info' : info, 'barmonths' : months,'barans' : ans, 'monthsL':monthsL, 'ansL':ansL, 'map1':map1 ,'final2': final2,'cityname':'pune'})

        
def citywise(request, city_name):
    disease = 'malaria'
    areaname = 'kothrud'
    
    if request.method == 'POST' :
        disease = request.POST['dis']
        areaname = request.POST['dis']

    city_name = city_name.lower()

    print(areaname, disease)

    cities=['Pune', 'Mumbai']
    mosquitos=['Abc', 'Xyz']

    diseases_dict = {
        'malaria': 0,'dengue': 0,'chikungunya': 0,'kalaazar': 0,'japaneseencephalitis': 0,'lymphaticfilariasis': 0,'yellowfever': 0
    }
    city=city_name
    #overall diseases percentage pie chart 
    docs = db.collection('co2_baited').where("city","==",city_name).get()

    #code
    for doc in docs:
        my_dict = doc.to_dict()
        for key in keys:
            if key in my_dict:
                diseases_dict[key]= diseases_dict[key] + my_dict[key]['percentage']

    ans.clear()
    values= []
    diseases = []
    for key in keys:
        ans.append(diseases_dict[key])
    

    for i in range(len(ans)):
        if ans[i]!=0:
            values.append(ans[i])
            diseases.append(keys[i])

    info = zip(diseases,values)
    print(diseases, values)

    #Bar Chart------------------------

    percentage_by_month = {'feb':0,'mar':0,'apr':0}
    docs = db.collection('co2_baited').where("city","==",city).get()
    for doc in docs:
        my_dict = doc.to_dict()
        if disease in my_dict:
            # print(my_dict[disease]['percentage'])
            date = my_dict['date'].split("_")[1]
            if date == "02":
                percentage_by_month['feb'] = percentage_by_month['feb'] + my_dict[disease]['percentage']
            elif date == "03":
                percentage_by_month['mar'] = percentage_by_month['mar'] + my_dict[disease]['percentage']
            elif date == "04":
                percentage_by_month['apr'] = percentage_by_month['apr'] + my_dict[disease]['percentage']
    
    
    months = ['feb','mar','apr']
    ans.clear()


    for month in months:
        ans.append(percentage_by_month[month])
    
    #print("Bar Chart-----------")
    #print(months,ans)
    
    #Bar Chart Ends------------------------

    #Line Chart------------------------
    docs = db.collection('co2_baited').get()
    dates= []
    for doc in docs:
        my_dict = doc.to_dict()
        dates.append(my_dict['date'])


    percentage_by_month = {'feb':0,'mar':0,'apr':0}
    for date in dates:
        date = date.split("_")[1]
        if date == "02":
            percentage_by_month['feb'] = percentage_by_month['feb'] + 1
        elif date == "03":
            percentage_by_month['mar'] = percentage_by_month['mar'] + 1
        elif date == "04":
            percentage_by_month['apr'] = percentage_by_month['apr'] + 1

    
    monthsL = ['feb','mar','apr']
    ansL=[]

    for month in monthsL:
        ansL.append(percentage_by_month[month])
    
    # print("Line Chart-----------")
    # print(monthsL,ansL)

    #Line Chart ends----------------------

    #Map1-----------------------
    
    map1 = []
    curr = []
    docs = db.collection('co2_baited').get()
    for doc in docs:
        curr.clear()
        my_dict = doc.to_dict()
        if (my_dict['location'] and my_dict['no']):
            loc = my_dict['location']
            loc = loc.split(",")
            curr.append(float(loc[0]))
            curr.append(float(loc[1]))
            curr.append(my_dict['no'])
            #print(curr)
            map1.append(list(curr))

    
    #Map2-------------------------
    final2 =[]
    curr1 = []
    docs = db.collection('co2_baited').get()
    for doc in docs:
        string = ''
        curr1.clear()
        my_dict = doc.to_dict()
        if (my_dict['location']):
            loc = my_dict['location']
            loc = loc.split(",")
            curr1.append(float(loc[0]))
            curr1.append(float(loc[1]))
            # curr2.append(list(curr1))
        if(my_dict['date'] and my_dict['ht']):
            string = ' date : '+ my_dict['date'] + ' br ' +'ht : ' + str(my_dict['ht'])
        for key in keys:
            if key in my_dict:
                string = string + ' br ' + key + ' : ' + str(my_dict[key]['percentage']) + ' '
        curr1.append(string)
        final2.append(list(curr1))

    map2=final2    
    #print(final2)

    #Area Pie Chart-------------
    area = []
    docs = db.collection('co2_baited').where("city","==",city_name).get()
    for doc in docs:
            my_dict = doc.to_dict()
            curr_area = my_dict['area']
            if curr_area not in area:
                area.append(curr_area)
    print(area)

    diseases_dict = {
        'malaria': 0,'dengue': 0,'chikungunya': 0,'kalaazar': 0,'japaneseencephalitis': 0,'lymphaticfilariasis': 0,'yellowfever': 0
    }
    
    docs = db.collection('co2_baited').where("area","==",areaname).get()
    
    for doc in docs:
        my_dict = doc.to_dict()
        for key in keys:
            if key in my_dict:
                diseases_dict[key] = diseases_dict[key] + my_dict[key]['percentage']
    #print(diseases_dict)

    ans.clear()
    for key in keys:
        ans.append(diseases_dict[key])

    #print(ans)
    non_zero_ans= []
    non_zero_diseases = []
    for i in range(len(ans)):
        if ans[i]!=0:
            non_zero_ans.append(ans[i])
            non_zero_diseases.append(keys[i])
    
    info2 = zip(non_zero_diseases, non_zero_ans)

    return render(request, 'dashboard/index.html', {'cities' : cities, 'mosquitos' : mosquitos, 'values' : values, 'info' : info, 'barmonths' : months,'barans' : ans, 'monthsL':monthsL, 'ansL':ansL, 'map1':map1 ,'final2': final2,'cityname':city_name, 'area':area,'nzans':non_zero_ans,'info2':info2})

def mosquitowise(request, mosquito_name):
    mosquito_name = mosquito_name.lower()
    return render(request, 'dashboard/index.html')