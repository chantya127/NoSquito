from django.shortcuts import render,redirect
from django.http import HttpResponse
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore



#setup
cred = credentials.Certificate("static/serviceAccountKey.json")
firebase_admin.initialize_app(cred)


def display(request):
    return render(request,'index/index1.html')
