from django.apps import AppConfig


class Trap1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'trap1'
