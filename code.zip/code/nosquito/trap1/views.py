from django.shortcuts import render
import tabula
from tabula.io import read_pdf
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

import io

from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfparser import PDFParser
from pdfminer.pdfdocument import PDFDocument
import dateutil
from dateutil import parser
from io import StringIO
import pdfminer
from pdfminer.high_level import extract_text
import pandas as pd


db = firestore.client()

# Create your views here.
def start(request):
    return render(request,'trap1/trap1_disp.html')

def check(request):
    # PDF CODE
    pass

def add(request):
    if request.method == 'POST' and request.FILES['myfile']:
        
        trapht = request.POST['trapht']
        traparea = request.POST['area']
        traplocation = request.POST['location']
        
        PDF = request.FILES['myfile']
        in_file = PDF
        pdfminer_string = StringIO()
        
        
        parser = PDFParser(in_file)
        doc = PDFDocument(parser)
        rsrcmgr = PDFResourceManager()
        device = TextConverter(rsrcmgr,
                            pdfminer_string,
                            laparams=LAParams())
        interpreter = PDFPageInterpreter(rsrcmgr, device)
        for page in PDFPage.create_pages(doc):
            interpreter.process_page(page)
        pdfminer_lines = pdfminer_string.getvalue().splitlines()
        pdfminer_lines = [ln.replace(" " , '') for ln in pdfminer_lines if ln]

        final_text = pdfminer_lines[14:][:-4]

        n = len(final_text)
        ptr = 0
        percentages = []
        viruses = [] 
        species = []
        cities = []
        dates = []

        #getting first percentages
        while (ptr < n):
            percent = final_text[ptr].replace(" " , '')
            if percent.isdigit():
                percentages.append(percent)
            else:
                break
            ptr+=1

        #getting other fields  
        for i in range(ptr , n-4+1 , 4):
            viruses.append(final_text[i])
            species.append(final_text[i+1])
            cities.append(final_text[i+2])
            dates.append(final_text[i+3]) 

        dataset = pd.DataFrame(
            {'Percentage': percentages,
            'Virus': viruses,
            'Species': species,
            'Location':cities,
            'Date':dates
            })
        df = dataset
        print(dataset)
        trap_no=0
        data = {
            'no': 'trap'+str(trap_no),
            'ht': int(trapht),#take input,
            'coordinates': 'xyz',
            'area':traparea,#take input
            'location': traplocation #take input
        }

        for index, row in df.iterrows():
            species = str('aedesaegypti,aedesalbopictus')
            species = species.split(",")
            row_data = {'percentage':row['Percentage'],'species':species}
            data[row['Virus']] = row_data
        data['city'] =  df['Location'][0]
        data['date'] = df['Date'][0]

        db.collection('co2_baited').document(data['no']).set(data)
        print("----------------Added in database")
    else:
        print("---------------------------------")
        print("NO PDF")
    return render(request,'trap1/trap1_disp.html')