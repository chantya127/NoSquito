from django.shortcuts import render

# Create your views here.
def start(request):
    return render(request,'trap2/trap2_disp.html')