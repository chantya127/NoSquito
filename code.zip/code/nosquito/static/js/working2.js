var mymap=null;
$(function() {
    var data, options;
    
    // headline charts------------------------------------------------------------
    // data = {
    //     labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    //     series: [
    //         [50, 29, 24, 40, 25, 24, 35],
    //         [14, 25, 18, 34, 29, 38, 44],
    //     ]
    // };

    // options = {
    //     height: 300,
    //     showArea: true,
    //     showLine: false,
    //     showPoint: false,
    //     fullWidth: true,
    //     axisX: {
    //         showGrid: false
    //     },
    //     lineSmooth: false,
    // };

    // new Chartist.Line('#headline-chart', data, options);




    // visits trend charts------------------------------------------------------------
    // data = {
    //     labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    //     series: [{
    //         name: 'series-real',
    //         data: [200, 380, 350, 320, 410, 450, 570, 400, 555, 620, 750, 900],
    //     }, {
    //         name: 'series-projection',
    //         data: [240, 350, 360, 380, 400, 450, 480, 523, 555, 600, 700, 800],
    //     }]
    // };

    // options = {
    //     fullWidth: true,
    //     lineSmooth: false,
    //     height: "270px",
    //     low: 0,
    //     high: 'auto',
    //     series: {
    //         'series-projection': {
    //             showArea: true,
    //             showPoint: false,
    //             showLine: false
    //         },
    //     },
    //     axisX: {
    //         showGrid: false,

    //     },
    //     axisY: {
    //         showGrid: false,
    //         onlyInteger: true,
    //         offset: 0,
    //     },
    //     chartPadding: {
    //         left: 20,
    //         right: 20
    //     }
    // };

    linem = []
    linem = monthsL.slice(1,-1);
    linem = linem.split(", ");
    
    for(var i=0;i<linem.length;i++){
        linem[i] = linem[i].slice(6,9);
    }

    linea=[]
    linea = ansL.slice(1,-1);
    linea = linea.split(", ");

    data = {
        labels:linem,
        series:[linea]
    };

    new Chartist.Line('#visits-trends-chart', data, {
        low: 0,
        showArea: true
      });




    // Bar chart------------------------------------------------------------
    barm = []
    barm = barmonths.slice(1,-1);
    barm = barm.split(", ");
    
    for(var i=0;i<barm.length;i++){
        barm[i] = barm[i].slice(6,9);
    }

    bara=[]
    bara = barans.slice(1,-1);
    bara = bara.split(", ");

    // console.log(bara)
    // console.log(barm)

    data = {
        labels:barm,
        series:[bara]
    };

    options = {
        height: 300,
        axisX: {
            showGrid: false
        },
    };

    var charts = new Chartist.Bar('#visits-chart', data, options);

    charts.on('draw', function(data) {
        if(data.type == 'bar') {
            data.element.animate({
                y2: {
                    dur: '3s',
                    from: data.y1,
                    to: data.y2
                }
            });
        }
    });

    //PIE Chart 2
    //Pie Chart------------------------------------------------------------
    
    
    var res=[]
    var labels=[]

    res = nzans.slice(1,-1);
    res = res.split(", ");
    
    for(var i=1;i<=res.length;i++){
        labels.push(i);
    }
    

    var chart = new Chartist.Pie('#pie-chart2', {
        series: res,
        labels: labels
      }, {
        donut: true,
        showLabel: true
      });
      
      chart.on('draw', function(data) {
        if(data.type === 'slice') {
          // Get the total path length in order to use for dash array animation
          var pathLength = data.element._node.getTotalLength();
      
          // Set a dasharray that matches the path length as prerequisite to animate dashoffset
          data.element.attr({
            'stroke-dasharray': pathLength + 'px ' + pathLength + 'px'
          });
      
          // Create animation definition while also assigning an ID to the animation for later sync usage
          var animationDefinition = {
            'stroke-dashoffset': {
              id: 'anim' + data.index,
              dur: 1000,
              from: -pathLength + 'px',
              to:  '0px',
              easing: Chartist.Svg.Easing.easeOutQuint,
              // We need to use `fill: 'freeze'` otherwise our animation will fall back to initial (not visible)
              fill: 'freeze'
            }
          };
      
          // If this was not the first slice, we need to time the animation so that it uses the end sync event of the previous animation
          if(data.index !== 0) {
            animationDefinition['stroke-dashoffset'].begin = 'anim' + (data.index - 1) + '.end';
          }
      
          // We need to set an initial value before the animation starts as we are not in guided mode which would do that for us
          data.element.attr({
            'stroke-dashoffset': -pathLength + 'px'
          });
      
          // We can't use guided mode as the animations need to rely on setting begin manually
          // See http://gionkunz.github.io/chartist-js/api-documentation.html#chartistsvg-function-animate
          data.element.animate(animationDefinition, false);
        }
      });
      
      // For the sake of the example we update the chart every time it's created with a delay of 8 seconds
      chart.on('created', function() {
        if(window.__anim21278907124) {
          clearTimeout(window.__anim21278907124);
          window.__anim21278907124 = null;
        }
        window.__anim21278907124 = setTimeout(chart.update.bind(chart), 10000);
      });


    //Pie Chart------------------------------------------------------------
    res=[]
    labels=[]

    res = values.slice(1,-1);
    res = res.split(", ");
    
    for(var i=1;i<=res.length;i++){
        labels.push(i);
    }

    var chart = new Chartist.Pie('#pie-chart', {
        series: res,
        labels: labels
      }, {
        donut: true,
        showLabel: true
      });
      
      chart.on('draw', function(data) {
        if(data.type === 'slice') {
          // Get the total path length in order to use for dash array animation
          var pathLength = data.element._node.getTotalLength();
      
          // Set a dasharray that matches the path length as prerequisite to animate dashoffset
          data.element.attr({
            'stroke-dasharray': pathLength + 'px ' + pathLength + 'px'
          });
      
          // Create animation definition while also assigning an ID to the animation for later sync usage
          var animationDefinition = {
            'stroke-dashoffset': {
              id: 'anim' + data.index,
              dur: 1000,
              from: -pathLength + 'px',
              to:  '0px',
              easing: Chartist.Svg.Easing.easeOutQuint,
              // We need to use `fill: 'freeze'` otherwise our animation will fall back to initial (not visible)
              fill: 'freeze'
            }
          };
      
          // If this was not the first slice, we need to time the animation so that it uses the end sync event of the previous animation
          if(data.index !== 0) {
            animationDefinition['stroke-dashoffset'].begin = 'anim' + (data.index - 1) + '.end';
          }
      
          // We need to set an initial value before the animation starts as we are not in guided mode which would do that for us
          data.element.attr({
            'stroke-dashoffset': -pathLength + 'px'
          });
      
          // We can't use guided mode as the animations need to rely on setting begin manually
          // See http://gionkunz.github.io/chartist-js/api-documentation.html#chartistsvg-function-animate
          data.element.animate(animationDefinition, false);
        }
      });
      
      // For the sake of the example we update the chart every time it's created with a delay of 8 seconds
      chart.on('created', function() {
        if(window.__anim21278907124) {
          clearTimeout(window.__anim21278907124);
          window.__anim21278907124 = null;
        }
        window.__anim21278907124 = setTimeout(chart.update.bind(chart), 10000);
      });


    // var sum = function(a, b) {
    //     return a + b
    // };
    // new Chartist.Pie('#pie-chart', data, {labelInterpolationFnc:function(value, idx) {
    //     var percentage = Math.round(value / data.series.reduce(sum) * 100) + '%';
    //     return animals[idx] + ' ' + percentage;
    // }});



    // real-time pie chart------------------------------------------------------------
    // var sysLoad = $('#system-load').easyPieChart({
    //     size: 130,
    //     barColor: function(percent) {
    //         return "rgb(" + Math.round(200 * percent / 100) + ", " + Math.round(200 * (1.1 - percent / 100)) + ", 0)";
    //     },
    //     trackColor: 'rgba(245, 245, 245, 0.8)',
    //     scaleColor: false,
    //     lineWidth: 5,
    //     lineCap: "square",
    //     animate: 800
    // });

    // var updateInterval = 3000; // in milliseconds

    // setInterval(function() {
    //     var randomVal;
    //     randomVal = getRandomInt(0, 100);

    //     sysLoad.data('easyPieChart').update(randomVal);
    //     sysLoad.find('.percent').text(randomVal);
    // }, updateInterval);

    // function getRandomInt(min, max) {
    //     return Math.floor(Math.random() * (max - min + 1)) + min;
    // }
      
    //Map---------------
    
    maps(1);    
    
});

    function maps(val){
        
        if(mymap!=null){
            mymap.remove();
        }
        
        mymap = L.map('mapid').setView([18.5104269, 73.7945643], 8);
        
        L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=sk.eyJ1IjoicHJhc3NhbmEiLCJhIjoiY2tuYndhejJ4MXZ2YTJubngxd2F3eDBlaSJ9.9cOwbh7rpSELZV7nUGDBFg', {
            attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
            maxZoom: 20,
            id: 'mapbox/streets-v11',
            tileSize: 512,
            zoomOffset: -1,
            accessToken: 'your.mapbox.access.token'
        }).addTo(mymap);        
        
        if(val==1){
            
            maps1();
        }
        else{
            maps2();
        }
    }

    function maps1(){
        //alert("1 " + mymap);
        val=1;
        // console.log(map1data);
        if(val==1){
            var x = document.getElementById("mapid");
            x.style.display="";
            var x2 = document.getElementById("mapid2");
            x2.style.display="none";
            //Map1---------------------------------------------------------
            var addressPoints = map1data;
            
            final1=[]
            final2=[]
            curr=[]

            // map1data = map1data.slice(2,-2);
            // map1d = map1data.split("], [");
            
            
            // for(var i=0;i<map1d.length;i++){
                
            //     map1d[i] = map1d[i].replace("&#x27;", "");
            //     //map1d[i] = map1d[i].replace(" ", "");
            //     map1d[i] = map1d[i].slice(0,-6);
                
            //     final1.push(map1d[i]);
            // }

            // for(var i=0;i<final1.length;i++){
            //     curr = []
            //     curr = final1[i].split(", ");
            //     final2.push(curr);
            // }
            // //console.log(final2);
            // addressPoints = final2;

            map1f = map1f.slice(2,-2);
            map1d = map1f.split("], [");
            
            //console.log(map1d);
            for(var i=0;i<map1d.length;i++){
                
                map1d[i] = map1d[i].replace("&#x27;", "");
                map1d[i] = map1d[i].replace(/br/g, "<br>");
                map1d[i] = map1d[i].replace(/ /g, "");
                map1d[i] = map1d[i].slice(0,-6);
                
                final1.push(map1d[i]);
            }

            for(var i=0;i<final1.length;i++){
                curr = []
                curr = final1[i].split(",");
                final2.push(curr);
            }
            //console.log(final2);
            addressPoints = final2;


            var markers = L.markerClusterGroup();
    
            for (var i = 1; i < addressPoints.length; i++) {
                var a = addressPoints[i];
                //console.log(a);
                var title = a[2];
                var marker = L.marker(new L.LatLng(a[0], a[1]), {
                    title: title
                });
                marker.bindPopup(title);
                markers.addLayer(marker);
            }
    
            mymap.addLayer(markers);
            
            var heat_data = [
                // lat, lng, intensity
                [-37.8210922667, 175.2209316333, "1"],
                [-37.8210819833, 175.2213903167, "0.2"],
            ]

            var heat = L.heatLayer(heat_data, {radius: 50}).addTo(mymap);
        }
    }
    function maps2()
    {
        //alert("2 " + mymap);

        var x = document.getElementById("mapid");
        x.style.display="none";
        var x2 = document.getElementById("mapid2");
        x2.style.display="";
        val=2;
        var mymap = L.map('mapid2').setView([-37.82, 175.23], 13);
            L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=sk.eyJ1IjoicHJhc3NhbmEiLCJhIjoiY2tuYndhejJ4MXZ2YTJubngxd2F3eDBlaSJ9.9cOwbh7rpSELZV7nUGDBFg', {
                attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
                maxZoom: 20,
                id: 'mapbox/streets-v11',
                tileSize: 512,
                zoomOffset: -1,
                accessToken: 'your.mapbox.access.token'
            }).addTo(mymap);

            if(val==2){
                //Map2---------------------------------------------------------
                
                all_data=[
                    [[51.5, -0.09],"I am a popup"]
                ]
                
                for(var i=0;i<all_data.length;i++){
                    var marker = L.marker(all_data[i][0]).addTo(mymap);
                    marker.bindPopup(all_data[i][1]).openPopup();
                }
                //[[LAT , LON , "String" ], [LAT , LON , "String" ]]
                //[ [ [LAT, LONG] , "String"], [[LAT, LONG] , "String"]]
                
               var circle = L.circle([51.508, -0.11], {
                   color: 'red',
                   fillColor: '#f03',
                   fillOpacity: 0.5,
                   radius: 500
               }).addTo(mymap);
               circle.bindPopup("I am a circle.");
            }
    }
